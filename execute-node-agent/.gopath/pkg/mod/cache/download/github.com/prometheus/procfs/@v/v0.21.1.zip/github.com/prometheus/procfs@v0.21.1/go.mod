module github.com/prometheus/procfs

go 1.25.0

require (
	github.com/google/go-cmp v0.7.0
	golang.org/x/sync v0.21.0
	golang.org/x/sys v0.46.0
)
